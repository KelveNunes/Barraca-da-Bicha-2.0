package br.com.sorveteria;

import br.com.sorveteria.cadastros.CadastrarCliente;
import org.junit.Test;

public class CadastrarClienteTest {

    @Test
    public void cadastrarCliente(){
        CadastrarCliente cadastro = new CadastrarCliente();


    }
}
