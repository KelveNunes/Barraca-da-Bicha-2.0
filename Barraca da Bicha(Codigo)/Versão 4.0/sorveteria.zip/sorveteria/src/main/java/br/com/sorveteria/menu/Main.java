package br.com.sorveteria.menu;

public class Main {

    public static void main(String[] args) {

        Menu inicar = new Menu();
        inicar.menu();

        return;
    }
}
